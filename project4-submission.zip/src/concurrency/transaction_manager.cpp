//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// transaction_manager.cpp
//
// Identification: src/concurrency/transaction_manager.cpp
//
// Copyright (c) 2015-2019, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "concurrency/transaction_manager.h"

#include <memory>
#include <mutex>  // NOLINT
#include <optional>
#include <shared_mutex>
#include <unordered_map>
#include <unordered_set>

#include "catalog/catalog.h"
#include "catalog/column.h"
#include "catalog/schema.h"
#include "common/config.h"
#include "common/exception.h"
#include "common/macros.h"
#include "concurrency/transaction.h"
#include "execution/execution_common.h"
#include "storage/table/table_heap.h"
#include "storage/table/tuple.h"
#include "type/type_id.h"
#include "type/value.h"
#include "type/value_factory.h"

namespace bustub {

auto TransactionManager::Begin(IsolationLevel isolation_level) -> Transaction * {
  std::unique_lock<std::shared_mutex> l(txn_map_mutex_);
  auto txn_id = next_txn_id_++;
  auto txn = std::make_unique<Transaction>(txn_id, isolation_level);
  auto *txn_ref = txn.get();
  txn_map_.insert(std::make_pair(txn_id, std::move(txn)));

  // TODO(fall2023): set the timestamps here. Watermark updated below.
  txn_ref->read_ts_ = running_txns_.commit_ts_;

  running_txns_.AddTxn(txn_ref->read_ts_);
  return txn_ref;
}

auto TransactionManager::VerifyTxn(Transaction *txn) -> bool {
  if (txn->GetWriteSets().empty()) {
    return true;
  }

  for (auto &[tran_id, ctxn] : txn_map_) {
    if (ctxn->state_ != TransactionState::COMMITTED) {
      continue;
    }

    if (ctxn->GetCommitTs() <= txn->GetReadTs()) {
      continue;
    }

    if (ctxn->GetWriteSets().empty()) {
      continue;
    }

    for (const auto &[table_oid, rids] : ctxn->GetWriteSets()) {
      auto table_info = catalog_->GetTable(table_oid);

      auto iter = txn->GetScanPredicates().find(table_oid);
      if (iter == txn->GetScanPredicates().cend()) {
        continue;
      }

      const auto &filter_exprs = iter->second;
      for (auto rid : rids) {
        auto rpage_guard = table_info->table_->AcquireTablePageReadLock(rid);
        auto rpage = rpage_guard.As<TablePage>();
        auto [meta, tuple] = table_info->table_->GetTupleWithLockAcquired(rid, rpage);

        std::vector<Tuple> w_tuples;

        if (meta.ts_ != ctxn->GetCommitTs()) {
          auto undo_link_opt = GetUndoLink(rid);
          UndoLink undo_link = undo_link_opt.value();
          std::vector<UndoLog> undo_logs;
          while (undo_link.IsValid()) {
            auto undo_log = GetUndoLog(undo_link);
            undo_logs.emplace_back(undo_log);
            if (undo_log.ts_ == ctxn->GetCommitTs()) {
              break;
            }
            undo_link = undo_log.prev_version_;
          }

          auto origin_tuple = ReconstructTuple(&table_info->schema_, tuple, meta, undo_logs);
          auto undo_log = GetUndoLog(undo_link);
          undo_link = undo_log.prev_version_;
          if (origin_tuple == std::nullopt) {
            auto undo_log = GetUndoLog(undo_link);
            undo_logs.emplace_back(undo_log);
            origin_tuple = ReconstructTuple(&table_info->schema_, tuple, meta, undo_logs);
            w_tuples.emplace_back(*origin_tuple);
          } else {
            w_tuples.emplace_back(*origin_tuple);
            if (undo_link.IsValid()) {
              auto undo_log = GetUndoLog(undo_link);
              undo_logs.emplace_back(undo_log);
              origin_tuple = ReconstructTuple(&table_info->schema_, tuple, meta, undo_logs);
              if (origin_tuple.has_value()) {
                w_tuples.emplace_back(*origin_tuple);
              }
            }
          }
        } else {
          if (!meta.is_deleted_) {
            w_tuples.emplace_back(tuple);
          }

          auto undo_link_opt = GetUndoLink(rid);
          if (undo_link_opt.has_value()) {
            auto undo_log = GetUndoLog(*undo_link_opt);
            auto origin_tuple = ReconstructTuple(&table_info->schema_, tuple, meta, {undo_log});
            if (origin_tuple.has_value()) {
              w_tuples.emplace_back(*origin_tuple);
            }
          }
        }

        for (const auto &tuple : w_tuples) {
          for (const auto &expr : filter_exprs) {
            auto value = expr->Evaluate(&tuple, table_info->schema_);
            if (!value.IsNull() && value.GetAs<bool>()) {
              return false;
            }
          }
        }
      }
    }
  }
  return true;
}

auto TransactionManager::Commit(Transaction *txn) -> bool {
  std::unique_lock<std::mutex> commit_lck(commit_mutex_);

  // TODO(fall2023): acquire commit ts!
  auto commit_ts = ++last_commit_ts_;

  if (txn->state_ != TransactionState::RUNNING) {
    throw Exception("txn not in running state");
  }

  if (txn->GetIsolationLevel() == IsolationLevel::SERIALIZABLE) {
    if (!VerifyTxn(txn)) {
      commit_lck.unlock();
      Abort(txn);
      return false;
    }
  }

  // TODO(fall2023): Implement the commit logic!
  for (const auto &[table_oid, rids] : txn->write_set_) {
    auto table = catalog_->GetTable(table_oid);
    for (const auto &rid : rids) {
      auto [meta, _] = table->table_->GetTuple(rid);
      meta.ts_ = commit_ts;
      table->table_->UpdateTupleMeta(meta, rid);
    }
  }

  std::unique_lock<std::shared_mutex> lck(txn_map_mutex_);

  // TODO(fall2023): set commit timestamp + update last committed timestamp
  // here.
  txn->commit_ts_ = commit_ts;

  txn->state_ = TransactionState::COMMITTED;
  running_txns_.UpdateCommitTs(txn->commit_ts_);
  running_txns_.RemoveTxn(txn->read_ts_);

  return true;
}

void TransactionManager::Abort(Transaction *txn) {
  if (txn->state_ != TransactionState::RUNNING && txn->state_ != TransactionState::TAINTED) {
    throw Exception("txn not in running / tainted state");
  }

  // TODO(fall2023): Implement the abort logic!
  for (const auto &[table_oid, rids] : txn->write_set_) {
    auto table = catalog_->GetTable(table_oid);
    for (const auto &rid : rids) {
      auto [new_meta, new_tuple] = table->table_->GetTuple(rid);

      auto undo_link = GetUndoLink(rid);
      auto undo_log = UndoLog{
          .is_deleted_ = true,
          .modified_fields_ = {},
          .tuple_ = {},
          .ts_ = 0,
          .prev_version_ = {},
      };
      if (undo_link) {
        undo_log = GetUndoLog(*undo_link);
      }
      auto old_tuple = ReconstructTuple(&table->schema_, new_tuple, new_meta, std::vector<UndoLog>({undo_log}));
      auto old_meta = TupleMeta{
          .ts_ = undo_log.ts_,
          .is_deleted_ = !old_tuple.has_value(),
      };
      if (old_tuple) {
        table->table_->UpdateTupleInPlace(old_meta, *old_tuple, rid);
      } else {
        table->table_->UpdateTupleInPlace(old_meta, GenerateNullTupleForSchema(&table->schema_), rid);
      }
    }
  }
  std::unique_lock<std::shared_mutex> lck(txn_map_mutex_);
  txn->state_ = TransactionState::ABORTED;
  running_txns_.RemoveTxn(txn->read_ts_);
}

void TransactionManager::GarbageCollection() {
  // UNIMPLEMENTED("not implemented");
  auto watermark = GetWatermark();
  auto table_names = catalog_->GetTableNames();

  auto txn_ref_map = std::unordered_map<txn_id_t, bool>();
  auto lck = std::unique_lock<std::shared_mutex>(txn_map_mutex_);
  for (const auto &[txn_id, _] : txn_map_) {
    txn_ref_map[txn_id] = false;
  }

  for (const auto &table_name : table_names) {
    auto table = catalog_->GetTable(table_name);
    auto iter = table->table_->MakeIterator();
    while (!iter.IsEnd()) {
      auto [meta, value] = iter.GetTuple();
      iter.operator++();

      if (meta.ts_ <= watermark) {
        UpdateUndoLink(value.GetRid(), std::nullopt);
        continue;
      }

      auto undo_link = GetUndoLink(value.GetRid());
      if (!undo_link) {
        continue;
      }

      while (undo_link->IsValid()) {
        auto iter = txn_map_.find(undo_link->prev_txn_);
        if (iter == txn_map_.end()) {
          break;
        }

        txn_ref_map[undo_link->prev_txn_] = true;
        auto undo_log = iter->second->GetUndoLog(undo_link->prev_log_idx_);
        if (undo_log.ts_ <= watermark) {
          auto new_undo_log = undo_log;
          new_undo_log.prev_version_ = {};
          iter->second->ModifyUndoLog(undo_link->prev_log_idx_, new_undo_log);
          break;
        }

        undo_link = undo_log.prev_version_;
      }
    }
  }

  auto txn_should_remove = [&](txn_id_t txn_id, const std::shared_ptr<bustub::Transaction> &txn) {
    auto is_commited_or_aborted =
        txn->state_ == TransactionState::COMMITTED || txn->state_ == TransactionState::ABORTED;
    auto is_not_referenced = !txn_ref_map[txn_id];

    return is_commited_or_aborted && is_not_referenced;
  };

  for (auto iter = txn_map_.begin(); iter != txn_map_.end();) {
    const auto &[txn_id, txn] = *iter;
    if (txn_should_remove(txn_id, txn)) {
      iter = txn_map_.erase(iter);
    } else {
      ++iter;
    }
  }
}

}  // namespace bustub
