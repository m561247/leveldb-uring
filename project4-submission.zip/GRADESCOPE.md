To create a fair learning environment for all students and avoid potential Academic Integrity Violations within Carnegie Mellon University, we ask you to sign this short agreement before submitting to Gradescope.

1. I agree NOT to make my solution public. i.e., DO NOT make it public on GitHub or create videos explaining the solution code.
2. I agree NOT to hack Gradescope. i.e., DO NOT retrieve private test cases from Gradescope, or bypass correctness checks.
3. I affirm that the work I submit for assessment is my original work. i.e., DO NOT purchase/copy solution from others.
4. I understand that the course staff does not provide official help for students outside CMU. i.e., DO NOT email the course staff or create GitHub issues for course-related questions. Use the unofficial Discord server.
I understand that if I violate the rules, I will be banned from using Gradescope.

Name: nosae
Affiliation (School/Company): non-cmu
Email: m561247
GitHub ID: m561247
Date: 2024-04-20

I understand that if I provide a fake signature, I will be banned from using Gradescope.
